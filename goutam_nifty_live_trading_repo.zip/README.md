# Goutam Nifty Live (Live Trading) — Ready Repo

This repository is ready to upload to GitHub. The GitHub Actions workflow will build a Windows single-file executable (`.exe`) using PyInstaller.

## Features
- Tick-by-tick NIFTY 50 live feed (WebSocket via SmartAPI)
- Optional live order placement (market orders) via SmartAPI REST
- App prompts for Access Token at runtime — your credentials stay local and private
- Every live order requires a local PIN confirmation before sending

## Steps to get the built .exe (no coding)
1. Create a new GitHub repository and upload all files from this zip to the repo root.
2. Commit & push to `main`.
3. In GitHub, open **Actions**, run the **Build Windows EXE (Live Trading)** workflow or push to main.
4. Download the produced artifact `goutam-nifty-live-trading-exe` from the workflow run.
5. Run the `.exe` on your Windows PC. It will open a small UI and ask for your Access Token; paste it.
6. To place a live order: enable Live Trading in sidebar, enter your local PIN, re-enter to confirm, and press "Place Market Order".

## Important safety notes
- The order API payload, endpoint, and parameter names in `smartapi_orderer.py` are placeholders. You MUST verify these against the Angel One SmartAPI REST docs. If the order call fails, provide the error and I will patch the payload/URLs.
- Test with small quantities first.
- Do NOT share your Access Token or credentials here. The app keeps them local.