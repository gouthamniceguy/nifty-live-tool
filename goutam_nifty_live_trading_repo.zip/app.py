import streamlit as st
import threading, time, json
from datetime import datetime, date, timedelta
import websocket

st.set_page_config(page_title="Goutam Nifty Live — Live Trading", layout="wide")

st.title("Goutam Nifty Live — Angel One SmartAPI (Tick & Live Trading)")
st.markdown("This app streams true tick-by-tick NIFTY 50 prices and can optionally place live orders via Angel One SmartAPI. "
            "You will be prompted for your daily Access Token. **Do NOT paste username/password here.**")

with st.expander("How to get Access Token (quick)"):
    st.markdown("""
1. Login to Angel One SmartAPI / SmartConnect using your client credentials and 2FA as usual.  
2. Generate Access Token from their portal or via the SmartAPI login flow.  
3. Paste the Access Token (only) into the field below when the app asks for it.
""")

api_key = st.text_input("API Key (optional) — leave blank if using access token only", type="password")
access_token = st.text_input("Paste today's Access Token here", type="password")

start_btn = st.button("Connect & Subscribe NIFTY 50 (tick)")

status = st.empty()
ticker_box = st.empty()
table_box = st.empty()

# Live trading controls
st.sidebar.header("Live Trading (requires Access Token)")
enable_live = st.sidebar.checkbox("Enable Live Trading (OFF by default)", value=False)
order_confirm_pin = st.sidebar.text_input("Order confirmation PIN (local only)", type="password")
default_qty = st.sidebar.number_input("Default Qty (lots/units)", min_value=1, value=1, step=1)

# Order panel (only visible when live trading is enabled)
if enable_live:
    st.sidebar.markdown("**Place Market Order**")
    side = st.sidebar.selectbox("Side", ["BUY", "SELL"])
    qty = st.sidebar.number_input("Qty", min_value=1, value=int(default_qty), step=1)
    place_btn = st.sidebar.button("Place Market Order (requires PIN)")
else:
    place_btn = False

if start_btn:
    if not access_token:
        st.error("Please paste your Access Token (from Angel One SmartAPI).")
    else:
        status.info("Starting local websocket client...")
        import smartapi_client, smartapi_orderer
        # start client in background
        def run_client():
            client = smartapi_client.SmartWSClient(access_token=access_token, api_key=api_key)
            try:
                client.connect_and_subscribe_nifty(on_tick_callback=lambda tick: (
                    ticker_box.metric(label="NIFTY 50 LTP", value=f"{tick.get('ltp', '')}", delta=f"{tick.get('change', '')}%"),
                    table_box.table([tick])
                ))
            except Exception as e:
                status.error(f"WebSocket client error: {e}")

        t = threading.Thread(target=run_client, daemon=True)
        t.start()
        status.success("WebSocket client started. Subscribed to NIFTY 50. Waiting for ticks...")

        # Order placement handling
        if enable_live and place_btn:
            if not order_confirm_pin:
                st.sidebar.error("Enter your local confirmation PIN to place orders.")
            else:
                # Confirm PIN by asking user to re-enter in a modal-style input (simple pattern)
                user_pin = st.sidebar.text_input("Re-enter PIN to confirm order", type="password", key="confirm_pin")
                if user_pin and user_pin == order_confirm_pin:
                    st.sidebar.info("PIN confirmed. Placing order...")
                    try:
                        res = smartapi_orderer.place_market_order(access_token=access_token, api_key=api_key,
                                                                  symbol="NIFTY 50", side=side, qty=int(qty))
                        st.sidebar.success(f"Order placed: {res}")
                    except Exception as e:
                        st.sidebar.error(f"Order placement failed: {e}")
                elif user_pin:
                    st.sidebar.error("PIN did not match. Order aborted.")